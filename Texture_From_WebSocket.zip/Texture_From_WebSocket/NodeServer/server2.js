const NodeMediaServer = require('node-media-server');
const WebSocket = require('ws');
const express = require('express');
const path = require('path');

const config = {
  rtmp: {
    port: 1935,
    chunk_size: 60000,
    gop_cache: true,
    ping: 60,
    ping_timeout: 30
  }
};

var nms = new NodeMediaServer(config);
nms.run();

const wss = new WebSocket.Server({ port: 8888 });

nms.on('postPublish', (id, StreamPath, args) => {
  let session = nms.getSession(id);
  session.on('video', (videoData) => {
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(videoData);
      }
    });
  });
});

// Create a new Express application
const app = express();

// Serve static files from the current directory
app.use(express.static(__dirname));

// Start the Express server
const httpServer = app.listen(8000, () => {
  console.log('HTTP Server is listening on port 8000');
});
